package model;

public class IwillDestroyYouTank extends Actor {

}
