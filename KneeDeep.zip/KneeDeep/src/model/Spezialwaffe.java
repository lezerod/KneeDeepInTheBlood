package model;

public class Spezialwaffe {

}
