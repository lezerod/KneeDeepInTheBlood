package gui.eingabe;

import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import model.Sumpfplanet;

public class EingabeViewControl {
	//Model
	private Sumpfplanet sumpfplanet;

	//view
	private EingabeView view;

	public EingabeViewControl(Sumpfplanet sumpfplanet){
		this.sumpfplanet = sumpfplanet;
		this.view = new EingabeView();

		//Eventhandler
		view.getScene().setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent event) {

				// TODO Auto-generated method stub

			}
		});;
	}
}
