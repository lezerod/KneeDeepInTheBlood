package gui.eingabe;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class EingabeView {
	private Scene scene;
	private int height = 640;
	private int wide = 480;

	private Group actor;
	private Node alien;
	private Node heldenfahrzeug;

	private static final String HERO_IMAGE_LOC = "http://dullahansoft.com/pixel/wp-content/uploads/2014/07/enterprise-big.png";
	private static final String PROJECTIL_IMAGE_LOC = "http://files.gamebanana.com/img/ico/sprays/510788ce439b7.gif";
	private static final String ENEMY_IMAGE_LOC = "http://vignette4.wikia.nocookie.net/metroid/images/4/40/Metroid_super.gif/revision/latest?cb=20090415203739";

	private Image alienImage;
	private Image heldenfahrzeugImage;

	private KeyCode up;
	private KeyCode down;
	private KeyCode left;
	private KeyCode right;
	private int counter = 0;

	public void show(Stage stage)
	{
		stage.setTitle("KneeDeepInTheBlood");
		stage.setScene(scene);
		stage.show();
	}


	public KeyCode getUp() {
		return up;
	}


	public void setUp(KeyCode up) {
		this.up = up;
	}


	public KeyCode getDown() {
		return down;
	}


	public void setDown(KeyCode down) {
		this.down = down;
	}


	public KeyCode getLeft() {
		return left;
	}


	public void setLeft(KeyCode left) {
		this.left = left;
	}


	public KeyCode getRight() {
		return right;
	}


	public void setRight(KeyCode right) {
		this.right = right;
	}


	public int getCounter() {
		return counter;
	}


	public void setCounter(int counter) {
		this.counter = counter;
	}

	public Scene getScene() {
		return scene;
	}

	public void setScene(Scene scene) {
		this.scene = scene;
	}

	public EingabeView()
	{
		up = KeyCode.UP;
		down = KeyCode.DOWN;
		left = KeyCode.LEFT;
		right = KeyCode.RIGHT;
		heldenfahrzeugImage = new Image(HERO_IMAGE_LOC,100,100,false,false);
		heldenfahrzeug = new ImageView(heldenfahrzeugImage);
		alienImage = new Image(ENEMY_IMAGE_LOC,100,100,false,false);
		alien = new ImageView(alienImage);
		actor = new Group(heldenfahrzeug, alien);
		actor.getChildren().addAll(alien,actor);
		heldenfahrzeug.relocate(wide/2, height/2);
		alien.relocate(250, 1);
		scene = new Scene(actor, wide, height, Color.BLACK);
	}




}
