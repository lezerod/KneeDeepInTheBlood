package model;

import java.util.ArrayList;

import javafx.stage.Stage;

public class Sumpfplanet {

	private Stage primaryStage = null;
	ArrayList<Alien>aliens = null;

	public Stage getPrimaryStage() {
		return primaryStage;
	}
	public void setPrimaryStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}
	public ArrayList<Alien> getAliens() {
		return aliens;
	}
	public void setAliens(ArrayList<Alien> aliens) {
		this.aliens = aliens;
	}
	public Sumpfplanet(Stage primaryStage) {
		super();
		this.primaryStage = primaryStage;
		this.aliens = aliens;
	}



}
