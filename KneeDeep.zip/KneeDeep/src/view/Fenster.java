package view;

import javafx.application.Application;
import javafx.stage.Stage;

public class Fenster extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {

		// TODO Auto-generated method stub

	}

	public static void show(){
		launch();
	}

}
