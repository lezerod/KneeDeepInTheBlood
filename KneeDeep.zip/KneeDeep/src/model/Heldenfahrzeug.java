package model;

public class Heldenfahrzeug extends Actor {



}
