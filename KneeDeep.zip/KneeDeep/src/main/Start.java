package main;

import gui.eingabe.EingabeView;
import javafx.application.Application;
import javafx.stage.Stage;
import model.Sumpfplanet;
import view.Fenster;

public class Start  {
	public static void main(String[] args) {
		Fenster.show();;
	}



}
