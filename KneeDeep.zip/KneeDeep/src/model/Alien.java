package model;

public class Alien extends Actor {

	public void throwSmackerBall()
	{

	}

}
